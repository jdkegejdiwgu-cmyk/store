import { MongoClient } from 'mongodb'
import { v4 as uuidv4 } from 'uuid'
import { NextResponse } from 'next/server'

// MongoDB connection (singleton)
let client
let db

async function connectToMongo() {
  if (!client) {
    client = new MongoClient(process.env.MONGO_URL)
    await client.connect()
    db = client.db(process.env.DB_NAME)
  }
  return db
}

function handleCORS(response) {
  response.headers.set('Access-Control-Allow-Origin', process.env.CORS_ORIGINS || '*')
  response.headers.set('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS')
  response.headers.set('Access-Control-Allow-Headers', 'Content-Type, Authorization, x-admin-token')
  response.headers.set('Access-Control-Allow-Credentials', 'true')
  return response
}

export async function OPTIONS() {
  return handleCORS(new NextResponse(null, { status: 200 }))
}

function isAdmin(request) {
  const token = request.headers.get('x-admin-token')
  return token && token === (process.env.ADMIN_PASSWORD || 'admin123')
}

function clean(doc) {
  if (!doc) return doc
  const { _id, ...rest } = doc
  return rest
}

const SEED_PRODUCTS = [
  {
    name: 'عطر فاخر - Luxury Perfume',
    description: 'عطر فرنسي فاخر برائحة تدوم طوال اليوم، مثالي للمناسبات الخاصة. عبوة 100 مل.',
    price: 3500,
    oldPrice: 5000,
    badge: 'الأكثر مبيعاً',
    stock: 50,
    images: ['https://images.unsplash.com/photo-1563170351-be82bc888aa4?crop=entropy&cs=srgb&fm=jpg&ixid=M3w3NDQ2NDJ8MHwxfHNlYXJjaHw0fHxwcm9kdWN0JTIwcGhvdG9ncmFwaHl8ZW58MHx8fHwxNzg2MTE2Njk3fDA&ixlib=rb-4.1.0&q=85']
  },
  {
    name: 'ساعة ذكية - Smart Watch',
    description: 'ساعة ذكية بشاشة لمس، تتبع اللياقة البدنية ومعدل ضربات القلب، متوافقة مع جميع الهواتف.',
    price: 8900,
    oldPrice: 12000,
    badge: 'جديد',
    stock: 30,
    images: ['https://images.unsplash.com/photo-1546868871-7041f2a55e12?crop=entropy&cs=srgb&fm=jpg&ixid=M3w3NDQ2NDJ8MHwxfHNlYXJjaHwzfHxwcm9kdWN0JTIwcGhvdG9ncmFwaHl8ZW58MHx8fHwxNzg2MTE2Njk3fDA&ixlib=rb-4.1.0&q=85']
  },
  {
    name: 'حذاء رياضي - Sneakers',
    description: 'حذاء رياضي عصري مريح، مناسب للجري والاستعمال اليومي. متوفر بعدة مقاسات.',
    price: 6500,
    oldPrice: 8000,
    badge: '',
    stock: 40,
    images: ['https://images.unsplash.com/photo-1542291026-7eec264c27ff?crop=entropy&cs=srgb&fm=jpg&ixid=M3w3NDQ2NDJ8MHwxfHNlYXJjaHwxfHxwcm9kdWN0JTIwcGhvdG9ncmFwaHl8ZW58MHx8fHwxNzg2MTE2Njk3fDA&ixlib=rb-4.1.0&q=85']
  },
  {
    name: 'سماعات لاسلكية - Wireless Earbuds',
    description: 'سماعات بلوتوث لاسلكية بجودة صوت عالية وعزل للضوضاء، مع علبة شحن.',
    price: 2900,
    oldPrice: 4200,
    badge: 'خصم',
    stock: 60,
    images: ['https://images.unsplash.com/photo-1606841837239-c5a1a4a07af7?crop=entropy&cs=srgb&fm=jpg&ixid=M3w4NjA2MjJ8MHwxfHNlYXJjaHwzfHx3aXJlbGVzcyUyMGVhcmJ1ZHN8ZW58MHx8fHwxNzg2MTE2NzA0fDA&ixlib=rb-4.1.0&q=85']
  },
  {
    name: 'حقيبة جلدية - Leather Handbag',
    description: 'حقيبة يد جلدية أنيقة بتصميم عصري، مساحة واسعة وجودة عالية.',
    price: 4800,
    oldPrice: 6500,
    badge: '',
    stock: 25,
    images: ['https://images.unsplash.com/photo-1605733513597-a8f8341084e6?crop=entropy&cs=srgb&fm=jpg&ixid=M3w4NjAzMjh8MHwxfHNlYXJjaHwxfHxsZWF0aGVyJTIwaGFuZGJhZ3xlbnwwfHx8fDE3ODYxMTY3MDR8MA&ixlib=rb-4.1.0&q=85']
  },
  {
    name: 'مجموعة العناية بالبشرة - Skincare Set',
    description: 'مجموعة متكاملة للعناية بالبشرة بمكونات طبيعية، تمنح بشرتك نضارة ونعومة.',
    price: 3200,
    oldPrice: 4000,
    badge: 'عرض خاص',
    stock: 45,
    images: ['https://images.unsplash.com/photo-1580870069867-74c57ee1bb07?crop=entropy&cs=srgb&fm=jpg&ixid=M3w4NjA1MTN8MHwxfHNlYXJjaHwzfHxjb3NtZXRpY3N8ZW58MHx8fHwxNzg2MTE2NzA0fDA&ixlib=rb-4.1.0&q=85']
  }
]

async function getDeliverySettings(db) {
  let doc = await db.collection('settings').findOne({ id: 'delivery' })
  if (!doc) {
    doc = { id: 'delivery', defaultFee: 500, fees: {} }
    await db.collection('settings').insertOne(doc)
  }
  return doc
}

function computeFee(settings, wilaya) {
  if (settings && settings.fees && settings.fees[wilaya] != null) return Number(settings.fees[wilaya])
  return Number(settings?.defaultFee || 0)
}

async function ensureSeed(db) {
  const count = await db.collection('products').countDocuments()
  if (count === 0) {
    const now = new Date()
    const docs = SEED_PRODUCTS.map((p, i) => ({
      id: uuidv4(),
      ...p,
      active: true,
      createdAt: new Date(now.getTime() - i * 1000)
    }))
    await db.collection('products').insertMany(docs)
  }
}

function toCSV(orders) {
  const headers = ['رقم الطلب', 'الاسم الكامل', 'رقم الهاتف', 'الولاية', 'البلدية', 'المنتج', 'الكمية', 'سعر المنتج (دج)', 'التوصيل (دج)', 'السعر الإجمالي (دج)', 'الحالة', 'التاريخ']
  const statusAr = { new: 'جديد', confirmed: 'مؤكد', shipped: 'تم الشحن', cancelled: 'ملغى' }
  const rows = orders.map(o => [
    o.orderNumber,
    o.fullName,
    o.phone,
    o.wilaya,
    o.commune,
    o.productName,
    o.quantity,
    o.subtotal != null ? o.subtotal : (o.unitPrice * o.quantity),
    o.deliveryFee || 0,
    o.total,
    statusAr[o.status] || o.status,
    new Date(o.createdAt).toLocaleString('en-GB')
  ])
  const escape = (v) => {
    const s = String(v ?? '')
    if (s.includes(',') || s.includes('"') || s.includes('\n')) {
      return '"' + s.replace(/"/g, '""') + '"'
    }
    return s
  }
  const lines = [headers, ...rows].map(r => r.map(escape).join(','))
  return '\uFEFF' + lines.join('\n')
}

async function handleRoute(request, { params }) {
  const { path = [] } = await params
  const route = `/${path.join('/')}`
  const method = request.method

  try {
    const db = await connectToMongo()
    await ensureSeed(db)

    // ---------- ADMIN LOGIN ----------
    if (route === '/admin/login' && method === 'POST') {
      const body = await request.json()
      if (body.password && body.password === (process.env.ADMIN_PASSWORD || 'admin123')) {
        return handleCORS(NextResponse.json({ success: true, token: body.password }))
      }
      return handleCORS(NextResponse.json({ success: false, error: 'كلمة المرور غير صحيحة' }, { status: 401 }))
    }

    // ---------- DELIVERY FEES ----------
    if (route === '/delivery-fees' && method === 'GET') {
      const settings = await getDeliverySettings(db)
      return handleCORS(NextResponse.json(clean(settings)))
    }

    if (route === '/delivery-fees' && method === 'PUT') {
      if (!isAdmin(request)) return handleCORS(NextResponse.json({ error: 'unauthorized' }, { status: 401 }))
      const body = await request.json()
      const update = {}
      if (body.defaultFee !== undefined) update.defaultFee = Number(body.defaultFee) || 0
      if (body.fees !== undefined && body.fees && typeof body.fees === 'object') {
        const cleaned = {}
        Object.keys(body.fees).forEach(k => {
          if (body.fees[k] !== '' && body.fees[k] != null) cleaned[k] = Number(body.fees[k]) || 0
        })
        update.fees = cleaned
      }
      await db.collection('settings').updateOne({ id: 'delivery' }, { $set: update }, { upsert: true })
      const settings = await getDeliverySettings(db)
      return handleCORS(NextResponse.json(clean(settings)))
    }

    // ---------- PRODUCTS ----------
    if (route === '/products' && method === 'GET') {
      const products = await db.collection('products').find({}).sort({ createdAt: -1 }).toArray()
      return handleCORS(NextResponse.json(products.map(clean)))
    }

    if (route === '/products' && method === 'POST') {
      if (!isAdmin(request)) return handleCORS(NextResponse.json({ error: 'unauthorized' }, { status: 401 }))
      const body = await request.json()
      const product = {
        id: uuidv4(),
        name: body.name || 'منتج بدون اسم',
        description: body.description || '',
        price: Number(body.price) || 0,
        oldPrice: body.oldPrice ? Number(body.oldPrice) : null,
        badge: body.badge || '',
        stock: body.stock != null ? Number(body.stock) : 0,
        images: Array.isArray(body.images) ? body.images : [],
        active: true,
        createdAt: new Date()
      }
      await db.collection('products').insertOne(product)
      return handleCORS(NextResponse.json(clean(product)))
    }

    if (route.startsWith('/products/') && method === 'GET') {
      const id = path[1]
      const product = await db.collection('products').findOne({ id })
      if (!product) return handleCORS(NextResponse.json({ error: 'not found' }, { status: 404 }))
      return handleCORS(NextResponse.json(clean(product)))
    }

    if (route.startsWith('/products/') && method === 'PUT') {
      if (!isAdmin(request)) return handleCORS(NextResponse.json({ error: 'unauthorized' }, { status: 401 }))
      const id = path[1]
      const body = await request.json()
      const update = {}
      ;['name', 'description', 'badge'].forEach(k => { if (body[k] !== undefined) update[k] = body[k] })
      if (body.price !== undefined) update.price = Number(body.price)
      if (body.oldPrice !== undefined) update.oldPrice = body.oldPrice ? Number(body.oldPrice) : null
      if (body.stock !== undefined) update.stock = Number(body.stock)
      if (body.images !== undefined) update.images = Array.isArray(body.images) ? body.images : []
      await db.collection('products').updateOne({ id }, { $set: update })
      const product = await db.collection('products').findOne({ id })
      return handleCORS(NextResponse.json(clean(product)))
    }

    if (route.startsWith('/products/') && method === 'DELETE') {
      if (!isAdmin(request)) return handleCORS(NextResponse.json({ error: 'unauthorized' }, { status: 401 }))
      const id = path[1]
      await db.collection('products').deleteOne({ id })
      return handleCORS(NextResponse.json({ success: true }))
    }

    // ---------- ORDERS ----------
    if (route === '/orders' && method === 'POST') {
      const body = await request.json()
      if (!body.fullName || !body.phone || !body.wilaya || !body.productId) {
        return handleCORS(NextResponse.json({ error: 'الرجاء ملء جميع الحقول المطلوبة' }, { status: 400 }))
      }
      const product = await db.collection('products').findOne({ id: body.productId })
      if (!product) return handleCORS(NextResponse.json({ error: 'المنتج غير موجود' }, { status: 404 }))
      const quantity = Number(body.quantity) || 1
      const unitPrice = product.price
      const subtotal = unitPrice * quantity
      const settings = await getDeliverySettings(db)
      const deliveryFee = computeFee(settings, body.wilaya)
      const order = {
        id: uuidv4(),
        orderNumber: 'DZ' + Date.now().toString().slice(-8),
        productId: product.id,
        productName: product.name,
        productImage: (product.images && product.images[0]) || '',
        quantity,
        unitPrice,
        subtotal,
        deliveryFee,
        total: subtotal + deliveryFee,
        fullName: body.fullName,
        phone: body.phone,
        wilaya: body.wilaya,
        commune: body.commune || '',
        notes: body.notes || '',
        status: 'new',
        createdAt: new Date()
      }
      await db.collection('orders').insertOne(order)
      return handleCORS(NextResponse.json(clean(order)))
    }

    if (route === '/orders' && method === 'GET') {
      if (!isAdmin(request)) return handleCORS(NextResponse.json({ error: 'unauthorized' }, { status: 401 }))
      const orders = await db.collection('orders').find({}).sort({ createdAt: -1 }).toArray()
      return handleCORS(NextResponse.json(orders.map(clean)))
    }

    if (route === '/orders/export' && method === 'GET') {
      if (!isAdmin(request)) return handleCORS(NextResponse.json({ error: 'unauthorized' }, { status: 401 }))
      const orders = await db.collection('orders').find({}).sort({ createdAt: -1 }).toArray()
      const csv = toCSV(orders.map(clean))
      return handleCORS(new NextResponse(csv, {
        status: 200,
        headers: {
          'Content-Type': 'text/csv; charset=utf-8',
          'Content-Disposition': 'attachment; filename="orders.csv"'
        }
      }))
    }

    if (route.startsWith('/orders/') && method === 'PUT') {
      if (!isAdmin(request)) return handleCORS(NextResponse.json({ error: 'unauthorized' }, { status: 401 }))
      const id = path[1]
      const body = await request.json()
      const allowed = ['new', 'confirmed', 'shipped', 'cancelled']
      if (!allowed.includes(body.status)) {
        return handleCORS(NextResponse.json({ error: 'invalid status' }, { status: 400 }))
      }
      await db.collection('orders').updateOne({ id }, { $set: { status: body.status } })
      const order = await db.collection('orders').findOne({ id })
      return handleCORS(NextResponse.json(clean(order)))
    }

    // ---------- STATS ----------
    if (route === '/stats' && method === 'GET') {
      if (!isAdmin(request)) return handleCORS(NextResponse.json({ error: 'unauthorized' }, { status: 401 }))
      const orders = await db.collection('orders').find({}).toArray()
      const productsCount = await db.collection('products').countDocuments()
      const totalRevenue = orders.filter(o => o.status !== 'cancelled').reduce((s, o) => s + (o.total || 0), 0)
      const byStatus = { new: 0, confirmed: 0, shipped: 0, cancelled: 0 }
      orders.forEach(o => { byStatus[o.status] = (byStatus[o.status] || 0) + 1 })
      return handleCORS(NextResponse.json({
        totalOrders: orders.length,
        productsCount,
        totalRevenue,
        byStatus
      }))
    }

    return handleCORS(NextResponse.json({ error: `Route ${route} not found` }, { status: 404 }))
  } catch (error) {
    console.error('API Error:', error)
    return handleCORS(NextResponse.json({ error: 'Internal server error' }, { status: 500 }))
  }
}

export const GET = handleRoute
export const POST = handleRoute
export const PUT = handleRoute
export const DELETE = handleRoute
export const PATCH = handleRoute
